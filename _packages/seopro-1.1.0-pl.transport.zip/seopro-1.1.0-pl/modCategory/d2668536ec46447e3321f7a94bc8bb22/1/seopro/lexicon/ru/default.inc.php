<?php
$_lang['seopro.keywords'] = 'Ключевые фразы';
$_lang['seopro.characters'] = 'Символы';
$_lang['seopro.characters.allowed'] = 'Разрешено символов';
$_lang['seopro.tips'] = 'SEO-PRO Советы!';
$_lang['seopro.focuskeywords'] = 'Фокусные фразы';
$_lang['seopro.focuskeywords_desc'] = 'Разделённые запятой';
$_lang['seopro.prevbox'] = 'Как это будет выглядеть в Google?';
$_lang['seopro.prevbox_yandex'] = 'Как это будет выглядеть в Yandex?';
$_lang['seopro.emptymetadescription']='<i>Для предварительного просмотра заполните поле Описание</i>';
$_lang['seopro.branding_text']='This site is optimized with the Sterc seoPro plugin - https://github.com/Sterc/SEOPro.';

$_lang['setting_seopro.delimiter'] = 'Разделитель в сниппете Google/Yandex';
$_lang['setting_seopro.delimiter_desc'] = 'Разделитель между Заголовком и Названием сайта';
