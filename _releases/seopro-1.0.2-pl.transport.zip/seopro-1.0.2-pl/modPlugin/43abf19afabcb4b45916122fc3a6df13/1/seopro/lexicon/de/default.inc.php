<?php
$_lang['seopro.keywords'] = 'Keywords';
$_lang['seopro.characters'] = 'Zeichen';
$_lang['seopro.characters.allowed'] = 'Erlaubte Zeichen';
$_lang['seopro.tips'] = 'SEO Tipps';
$_lang['seopro.focuskeywords'] = 'Keywords für diese Seite';
$_lang['seopro.focuskeywords_desc'] = 'durch Komma getrennt, ohne Leerzeichen';
$_lang['seopro.prevbox'] = 'Google-Vorschau';
$_lang['seopro.emptymetadescription']='<i>Bitte geben Sie eine Beschreibung ein.</i>';

$_lang['setting_seopro.delimiter'] = 'Trennzeichen in Google-Vorschau.';
$_lang['setting_seopro.delimiter_desc'] = 'Trennzeichen zwischen Titel und Seitenname.';
